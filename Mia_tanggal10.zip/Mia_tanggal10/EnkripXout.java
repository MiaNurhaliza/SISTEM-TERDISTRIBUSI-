/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mia_tanggal10;

/**
 *
 * @author LAB-MM
 */
public class EnkripXout {
    private static String encrypt(String plainText, String secretKey){
        StringBuilder encrypedString = new StringBuilder();
    int encyptedInt;
    
    for (int i = 0; i < plainText.length(); i++){
        int plainTextInt = (int) (plainText.charAt(i) - 'A');
        int secretKeyInt = (int) (secretKey.charAt(i) - 'A');
        encryptedString.append((char) ((encryptedInt) + (int) 'A'));
    }
    return encryptedString.toString();
    
    
    }
    
    
}
